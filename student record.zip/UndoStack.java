public class UndoStack {

    private class Node {
        Student student;
        Node next;

        Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node top;

    // Constructor
    public UndoStack() {
        top = null;
    }

    // Push a deleted student onto the stack
    public void push(Student student) {
        Node newNode = new Node(student);
        newNode.next = top;
        top = newNode;
    }

    // Remove and return the top student
    public Student pop() {
        if (isEmpty()) {
            return null;
        }

        Student student = top.student;
        top = top.next;

        return student;
    }

    // View the top student without removing it
    public Student peek() {
        if (isEmpty()) {
            return null;
        }

        return top.student;
    }

    // Check whether the stack is empty
    public boolean isEmpty() {
        return top == null;
    }
}