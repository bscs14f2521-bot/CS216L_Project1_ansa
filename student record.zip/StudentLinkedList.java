public class StudentLinkedList {

    private class Node {
        Student student;
        Node next;

        Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node head;

    // Constructor
    public StudentLinkedList() {
        head = null;
    }

    // Add a student at the end
    public void addStudent(Student student) {
        Node newNode = new Node(student);

        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;

        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
    }

    // Display all students
    public void displayStudents() {
        if (head == null) {
            System.out.println("No student records found.");
            return;
        }

        Node current = head;

        while (current != null) {
            current.student.displayStudent();
            current = current.next;
        }
    }

    // Search for a student by ID
    public Student searchStudent(int studentId) {
        Node current = head;

        while (current != null) {
            if (current.student.getStudentId() == studentId) {
                return current.student;
            }

            current = current.next;
        }

        return null;
    }

    // Delete a student by ID
    public Student deleteStudent(int studentId) {
        if (head == null) {
            return null;
        }

        // If the first student matches
        if (head.student.getStudentId() == studentId) {
            Student removedStudent = head.student;
            head = head.next;
            return removedStudent;
        }

        Node current = head;

        while (current.next != null) {
            if (current.next.student.getStudentId() == studentId) {
                Student removedStudent = current.next.student;
                current.next = current.next.next;
                return removedStudent;
            }

            current = current.next;
        }

        return null;
    }


public void sortByGpa() {
    if (head == null || head.next == null) {
        System.out.println("Not enough records to sort.");
        return;
    }

    boolean swapped;

    do {
        swapped = false;
        Node current = head;

        while (current.next != null) {
            if (current.student.getGpa()
                    < current.next.student.getGpa()) {

                Student temp = current.student;
                current.student = current.next.student;
                current.next.student = temp;

                swapped = true;
            }

            current = current.next;
        }
    } while (swapped);

    System.out.println("Students sorted by GPA.");
}


    // Check whether the list is empty
    public boolean isEmpty() {
        return head == null;
    }
}