import java.util.Scanner;

public class Main {

    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {

        StudentLinkedList studentList = new StudentLinkedList();
        UndoStack undoStack = new UndoStack();

        int choice;

        do {
            System.out.println("\n===== STUDENT RECORD SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Undo Last Deletion");
            System.out.println("6. Sort Students by Marks");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            choice = readInt();

            switch (choice) {

                case 1:
                    addStudent(studentList);
                    break;

                case 2:
                    studentList.displayStudents();
                    break;

                case 3:
                    searchStudent(studentList);
                    break;

                case 4:
                    deleteStudent(studentList, undoStack);
                    break;

                case 5:
                    undoDeletion(studentList, undoStack);
                    break;

                case 6:
                    studentList.sortByGpa();
                    studentList.displayStudents();
                    break;

                case 7:
                    System.out.println("Exiting Student Record System.");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 7);

        input.close();
    }

    // Read an integer safely
    private static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(input.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid whole number: ");
            }
        }
    }

    // Read a decimal number safely
    private static double readDouble() {
        while (true) {
            try {
                double value = Double.parseDouble(input.nextLine().trim());

                if (Double.isFinite(value)) {
                    return value;
                }

                System.out.print("Enter a finite number: ");
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid number: ");
            }
        }
    }

    // Add a new student
    private static void addStudent(StudentLinkedList list) {

    System.out.print("Enter Student ID: ");
    int id = readInt();

    if (id <= 0) {
        System.out.println("Student ID must be positive.");
        return;
    }

    if (list.searchStudent(id) != null) {
        System.out.println("This Student ID already exists.");
        return;
    }

    System.out.print("Enter Student Name: ");
    String name = input.nextLine().trim();

    if (name.isEmpty()) {
        System.out.println("Name cannot be empty.");
        return;
    }

    System.out.print("Enter GPA (0.0-4.0): ");
    double gpa = readDouble();

    if (gpa < 0.0 || gpa > 4.0) {
        System.out.println("GPA must be between 0.0 and 4.0.");
        return;
    }

    Student student = new Student(id, name, gpa);
    list.addStudent(student);

    System.out.println("Student added successfully!");

    }

    // Search for a student
    private static void searchStudent(StudentLinkedList list) {

        System.out.print("Enter Student ID to search: ");
        int id = readInt();

        Student student = list.searchStudent(id);

        if (student != null) {
            System.out.println("Student found:");
            student.displayStudent();
        } else {
            System.out.println("Student not found.");
        }
    }

    // Delete a student and save it for undo
    private static void deleteStudent(
            StudentLinkedList list, UndoStack stack) {

        System.out.print("Enter Student ID to delete: ");
        int id = readInt();

        Student deletedStudent = list.deleteStudent(id);

        if (deletedStudent != null) {
            stack.push(deletedStudent);
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    // Restore the most recently deleted student
    private static void undoDeletion(
            StudentLinkedList list, UndoStack stack) {

        if (stack.isEmpty()) {
            System.out.println("There is no deletion to undo.");
            return;
        }

        Student student = stack.pop();

        // Avoid restoring a duplicate ID
        if (list.searchStudent(student.getStudentId()) != null) {
            System.out.println(
                "Cannot restore: this Student ID already exists.");
            stack.push(student);
            return;
        }

        list.addStudent(student);
        System.out.println("Last deletion undone successfully!");
        student.displayStudent();
    }
}